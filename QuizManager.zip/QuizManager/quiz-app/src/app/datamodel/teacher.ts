export class Teacher{
    id: number;
    name: string;

    constructor(id: number, name: string, score: number){
        this.id = id
        this.name = name
    }
}