package fr.epita.quiz.services.dataaccess;

import org.springframework.stereotype.Repository;

import fr.epita.quiz.datamodel.Student;

@Repository
public class StudentJPADAO extends GenericDAO<Student>{
	

	@Override
	public void prepareSearch(Student criteria, QueryHolder<Student> holder) {
		holder.setQueryString("from Student as s where s.name like :name"); 
		holder.setClassName(Student.class);
		holder.putParameter("name", "%" +  criteria.getName() + "%");
	}
	
 /*
	public void login(Student criteria2, QueryHolder<Student> holder) {
		holder.setQueryString("from Student as s where s.name=:name and s.password=:password"); 
		holder.setClassName(Student.class);
		holder.putParameter("name", "%" +  criteria2.getName() + "%");
		holder.putParameter("password", "%" +  criteria2.getPassword() + "%");
	}
*/
}
