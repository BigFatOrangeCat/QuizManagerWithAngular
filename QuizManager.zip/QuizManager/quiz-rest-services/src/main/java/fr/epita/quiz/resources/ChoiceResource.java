package fr.epita.quiz.resources;


import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import fr.epita.quiz.datamodel.Choice;
import fr.epita.quiz.services.dataaccess.ChoiceJPADAO;


@Path("/choices")
public class ChoiceResource {

	@Inject
	ChoiceJPADAO choiceDAO;
	
	@GET
	@Path("/search")
	@Produces(value = { MediaType.APPLICATION_JSON })
	public Response findAllchoices(@QueryParam("s") String inputString) {
		Choice criteria = new Choice();
		criteria.setText(inputString);
		List<Choice> searchResults = choiceDAO.search(criteria);
		return Response.ok(searchResults).build();
	}
	
	@POST
	@Path("/create")
	@Consumes(value = { MediaType.APPLICATION_JSON })
	public Response createchoice(Choice choice) throws URISyntaxException {
		choiceDAO.create(choice);
		return Response.created(URI.create("choices/" + String.valueOf(choice.getId()))).build();
	}
	
	@PUT
	@Path("/update")
	@Consumes
	public Response updatechoice(Choice choice) throws URISyntaxException {
		choiceDAO.update(choice);
		return Response.ok("choice" + choice.getId() + "updated").build();
	}
	
	@DELETE
	@Path("/delete")
	@Consumes
	public Response detelechoice(Choice choice) throws URISyntaxException {
		choiceDAO.delete(choice);
		return Response.ok("choice" + choice.getId() + "deleted").build();
	}
}
