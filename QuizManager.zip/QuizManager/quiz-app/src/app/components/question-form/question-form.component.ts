import { Component, OnInit } from '@angular/core';
import { Question } from 'src/app/datamodel/question';
import { QuestionService } from 'src/app/services/question.service';
import { Choice } from 'src/app/datamodel/choice';

@Component({
  selector: 'app-question-form',
  templateUrl: './question-form.component.html',
  styleUrls: ['./question-form.component.css']
})
export class QuestionFormComponent implements OnInit {

  question : Question = new Question('');


  constructor(private questionService : QuestionService) { }

  ngOnInit() {
  }

  saveQuestions() : void{
    this.questionService.saveQuestions(this.question);
    this.question = new Question('');
  }

}
