package fr.epita.quiz.services.dataaccess;

import org.springframework.stereotype.Repository;

import fr.epita.quiz.datamodel.Teacher;

@Repository
public class TeacherJPADAO {

	public void prepareSearch(Teacher criteria, QueryHolder<Teacher> holder) {
		holder.setQueryString("from Teacher as s where s.name like :name"); 
		holder.setClassName(Teacher.class);
		holder.putParameter("name", "%" +  criteria.getName() + "%");
	}
	
/*
	public void login(Teacher criteria2, QueryHolder<Teacher> holder) {
		holder.setQueryString("from Teacher as s where s.name=:name and s.password=:password"); 
		holder.setClassName(Teacher.class);
		holder.putParameter("name", "%" +  criteria2.getName() + "%");
		holder.putParameter("password", "%" +  criteria2.getPassword() + "%");
	}
*/
}
