import { Component, OnInit } from '@angular/core';
import { QuestionService } from 'src/app/services/question.service';

@Component({
  selector: 'app-question-delete',
  templateUrl: './question-delete.component.html',
  styleUrls: ['./question-delete.component.css']
})
export class QuestionDeleteComponent implements OnInit {
  name: string = ''
  questionList: any;


  constructor(private questionService: QuestionService) { }

  ngOnInit() {


    this.questionService.deleteQuestions('','').then(data=>{
    });
  }
}
