package fr.epita.quiz.resources;

import java.net.URI;

import java.util.*;

import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.Column;
import javax.persistence.ManyToOne;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import fr.epita.quiz.datamodel.Choice;
import fr.epita.quiz.datamodel.Question;
import fr.epita.quiz.services.dataaccess.ChoiceJPADAO;
import fr.epita.quiz.services.dataaccess.QuestionJPADAO;
import fr.epita.quiz.services.dataaccess.QuizDataService;



@Path("/quiz")
public class QuizResource {
	
	@Inject
	QuizDataService quizDataService;
	
	@Inject
	ChoiceJPADAO choiceDAO;

	@Inject
	QuestionJPADAO questionDAO;
	
	@GET
	@Path("/quiz")
	@Produces(value = { MediaType.APPLICATION_JSON })
	//Since this is a quiz all questions and corresponding choices are collected
	public Response findAllQuestions(@QueryParam("") String inputString) {
		
		HashMap<Question,List> questionChoiceSet=new HashMap<Question, List>();
		
		Question criteria = new Question();
		criteria.setContent(inputString);
		
		List<Question> searchResults = questionDAO.search(criteria);
		
		for(Question questions : searchResults)
		{
			Choice ques_reference = new Choice();
			List<Choice> choiceResult=choiceDAO.search(ques_reference);
			

				questionChoiceSet.put(questions, choiceResult);
				
		}
		
		return Response.ok(searchResults).build();
	}
}
