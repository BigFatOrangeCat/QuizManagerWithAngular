import { Question } from "./question";

export class Choice{
    id: number;
    text: string;
    valid: boolean;
    question: Question;

    content : string;
    
    constructor(id: number, text: string, valid: boolean, question: Question){
        this.id = id;
        this.text = text;
        this.valid = valid;
        this.question = question;
    }

}