import { Injectable } from '@angular/core';
import { Question } from '../datamodel/question';
import { HttpClient } from '@angular/common/http';
import { Choice } from '../datamodel/choice';
import { Teacher } from '../datamodel/teacher';
import { Student } from '../datamodel/student';

@Injectable({
  providedIn: 'root'
})


export class QuestionService {


  url : string = "localhost:8080/quiz-rest-service/rest/"

  questionList : Question[] = [
    new Question('Who is the king of the world?'),
    new Question('Who is the teacher of the EPITA Java class?')];
  questionDeleteConnection: '/detele';
  choiceDeleteConnection: '/detele';
  teacherDeleteConnection: '/detele';

  constructor(private http: HttpClient) { }

  getQuestions() : Promise<Question[]> {

    //return this.questionList

    return this.http.get<Question[]>(this.url).toPromise()

  }

  saveQuestions(question: Question): any {
    return this.http.post<Question>(this.url + "/create", question)
    //this.questionList.push(question);
  }

  deleteQuestions(name: string, questionName: string): any {
    let connection = this.url + this.questionDeleteConnection + 'name' + name
    return this.http.get<Boolean>(connection).toPromise()
  }

  getChoices() : Promise<Choice[]> {

    //return this.questionList

    return this.http.get<Choice[]>(this.url).toPromise()

  }

  saveChoices(choice: Choice): any {
    return this.http.post<Choice>(this.url + "/create", choice)
    //this.questionList.push(question);
  }

  deleteChoice(name: string, choiceName: string): any {
    let connection = this.url + this.choiceDeleteConnection + 'name' + name
    return this.http.get<Boolean>(connection).toPromise()
  }

  getTeachers() : Promise<Teacher[]> {

    //return this.questionList

    return this.http.get<Teacher[]>(this.url).toPromise()

  }

  deleteTeacher(name: string, teacherName: string): any {
    let connection = this.url + this.teacherDeleteConnection + 'name' + name
    return this.http.get<Boolean>(connection).toPromise()
  }

  saveTeachers(teacher: Teacher): any {
    return this.http.post<Teacher>(this.url + "/create", teacher)
    //this.questionList.push(question);
  }

  getStudents() : Promise<Student[]> {

    //return this.questionList

    return this.http.get<Student[]>(this.url).toPromise()

  }

  deleteTeachers(name: string, choiceName: string): any {
    let connection = this.url + this.teacherDeleteConnection + 'name' + name
    return this.http.get<Boolean>(connection).toPromise()
  }

  saveStudents(student: Student): any {
    return this.http.post<Student>(this.url + "/create", student)
    //this.questionList.push(question);
  }


}

