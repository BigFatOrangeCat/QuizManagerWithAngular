export class Question{

    content : string;
    
    constructor(text : string){
        this.content = text;
    }

}